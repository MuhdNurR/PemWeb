<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "db_covid";
$koneksi    = mysqli_connect($host, $user, $password, $database);
